#include "RK4.h"
#include "ODEs.h"
#include <vector>


double RK4_h(double h,double v,double H) { //Function to calculate height using the 4th order runge kutta method in SI Units (Small h is step size,large H is height)
    //K parameters
        double hk1=h*hdot(v);
        double hk2=h*hdot(v+0.5*h);
        double hk3=h*hdot(v+0.5*h);
        double hk4=h*hdot(v+h);
        
        return H+(1.0/6.0)*hk1+(1.0/3.0)*(hk2+hk3)+(1.0/6.0)*hk4;
}

double RK4_v(double h,double m, double v,vector<double> V ) { //Function to calculate velocity using the 4th order runge kutta method in SI Units (little h is step size)
    //K parameters
        double vk1=h*vdot(m,v,V);
        double vk2=h*vdot(m+0.5*h,v+0.5*vk1,V);
        double vk3=h*vdot(m+0.5*h,v+0.5*vk2,V);
        double vk4=h*vdot(m,v+vk3,V);
        
        return v+(1.0/6.0)*vk1+(1.0/3.0)*(vk2+vk3)+(1.0/6.0)*vk4;
        
}

double RK4_m(double h,double m, vector<double> V ) { //Function to calculate mass using the 4th order runge kutta method in SI Units (little h is step size)
    //K parameters
        double mk1=h*mdot(V[8]);
        double mk2=h*mdot(V[8]);
        double mk3=h*mdot(V[8]);
        double mk4=h*mdot(V[8]);
        
       return m+(1.0/6.0)*mk1+(1.0/3.0)*(mk2+mk3)+(1.0/6.0)*mk4; 
}