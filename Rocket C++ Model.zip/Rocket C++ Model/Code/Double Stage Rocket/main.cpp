#include <iostream>
#include <fstream>
#include <vector>
#include <tgmath.h>

//Header Functions (Limited by time so only make 2 of the functions into headers, would have made the rest into headers also if I had time)
#include "ODEs.h" 
#include "RK4.h"

using namespace std;

//Classes
class timef { 
private:
    double T; //important to keep t private as if there were a mistake in t, the real world accuracy would be compormised.

public:
    double timestep;

//Functions (one I didnt have time to turn into headers)
void tinc() {; //increases time by time step h
    T=T+timestep;
}

double getT() { // Returns time
    return T;
}

void setT(double num) { // Sets time
    T= num;
}

};

class status{ //States which rocket booser is in use
public:
string Rstatus;
    
};



int main()
{
	//Data In
    ifstream DataIn ("parameters.txt");
    
    vector<double> parameters; //Vector to store all parameters from parameters.txt
    
    double wv1; //Working variable
    
    while(DataIn >> wv1) { //Adding values from parameters.txt to vector
        parameters.push_back(wv1); 
    }
    
    //Initializing
    
    //Vectors for three variables
    vector<double> height ={parameters[4]};
    vector<double> velocity ={parameters[3]};
    vector<double> mass ={parameters[5]+parameters[11]};
    
    //Data Out set up
    ofstream DataOut("output.txt",ios::trunc); //Creating/clearing a txt file. 
    //Initial condition data out
    DataOut << 0 << " " << height[0] << " " << velocity[0] << " " << mass[0] << endl;
    
    
    //Runge Kutta implentation
    
    //Phase 1 - Stage 1 of rocket.
   
    
    int i=0; //Counting variable used to access specific parameters in vector
    
    timef t1;
    t1.setT(0.0); //setting t0
    t1.timestep =parameters[10]; //Step Size
    
     status stat1;
    stat1.Rstatus="Engine 1";
    cout << stat1.Rstatus << " at t="<< t1.getT() <<   endl;
    
    while (height[i]>=0) { //Checkin if the rocket has reached the ground
        
        //Checking if there is fuel remaining in the first stage
        if (mass[i]<=parameters[11]+parameters[6]) {
            break; //If so then break loop and move to next phase
        }
        
        // Updating Time and i
        t1.tinc();
        i++;
        
        //Calculating Variables
        //Height
        height.push_back(RK4_h(parameters[10],velocity[i-1],height[i-1]));
        
        //Velocity
        velocity.push_back(RK4_v(parameters[10],mass[i-1],velocity[i-1],parameters));
        
        //Mass
        mass.push_back(RK4_m(parameters[10],mass[i-1],parameters));
        
        //Outputting parameters
        DataOut << t1.getT() << " " << height[i] << " " << velocity[i] << " " << mass[i] << endl; 
        
    }
    
    //Adjusting parameters due to first stage ejection
    mass[i]=parameters[11]; //New Mass
    
    parameters[7]=parameters[13];//New Area
    parameters[8]=parameters[14];//New mf
    parameters[9]=parameters[15];//New ue
    
    stat1.Rstatus="Engine 2";
    cout << stat1.Rstatus << " at t="<< t1.getT() <<   endl;
    
    
    //Phase 2 - Stage 2 of rocket
    while (height[i]>=0) { 
        if(mass[i]<parameters[12]) { //Checking if fuel is gone in the 2nd stage.
            break;
        }
        
        // Updating Time and i
        t1.tinc();
        i++;
        
        //Calculating Variables
        //Height
        height.push_back(RK4_h(parameters[10],velocity[i-1],height[i-1]));
        
        
        //Mass
        mass.push_back(RK4_m(parameters[10],mass[i-1],parameters));
        
        //Velocity
        velocity.push_back(RK4_v(parameters[10],mass[i-1],velocity[i-1],parameters));
        
        //Outputting parameters
        DataOut << t1.getT() << " " << height[i] << " " << velocity[i] << " " << mass[i] << endl; 
        
    }
    
    //Adjustments due to fuel running out (no fuel means mf=0)
    parameters[8]=0;
    
    stat1.Rstatus="No engine";
    cout << stat1.Rstatus << " at t="<< t1.getT() <<   endl;
    
    
    //Phase 3 (When mass=mr and mf=0)
    while (height[i]>=0) { 
        // Updating Time and i
        t1.tinc();
        i++;
        
        //Calculating Variables
        //Height
        height.push_back(RK4_h(parameters[10],velocity[i-1],height[i-1]));
        
        //Mass
        mass.push_back(parameters[12]);
        
        //Velocity
        velocity.push_back(RK4_v(parameters[10],mass[i-1],velocity[i-1],parameters));
        
        //Outputting parameters
        DataOut << t1.getT() << " " << height[i] << " " << velocity[i] << " " << mass[i] << endl; 
        
    }
    
    DataOut.close(); // Closing file
    
    return 0;
}




