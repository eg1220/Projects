#include "ODEs.h"
#include <cmath>
#include <vector>

double hdot(double v) { //Function to calculate hdot ie the derivative of height with respect to time in SI Units
    return v;
}

double vdot(double m,double v,vector<double> &V) { //Function to calculate vdot ie the derivative of velocty with respect to time in SI Units
    return -V[1]-(0.5*V[0]*v*abs(v)*V[2]*V[7])/m+(v*V[8]*V[9])/(abs(v)*m);
}

double mdot(double mf) { //Function to calculate mdot ie the derivative of mass with respect to time in SI Units
    return -mf;
}
