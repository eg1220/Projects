#pragma once
#include <vector>

using namespace std;

double RK4_h(double h,double v,double H);
double RK4_v(double h,double m, double v,vector<double> V );
double RK4_m(double h,double m, vector<double> V );