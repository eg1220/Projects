#pragma once
#include <vector>

using namespace std;

double hdot(double v);
double vdot(double m,double v,vector<double> &V) ;
double mdot(double mdf);
